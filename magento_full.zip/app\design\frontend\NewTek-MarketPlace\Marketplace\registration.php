<?php
\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::THEME,
    'frontend/NewTek-MarketPlace/Marketplace',
    __DIR__
);
